DECAY0.1
========

My own update of DECAY0 to include rare decays on Xe isotopes.

Changelog:
----------

14/01/2013 :
     - implemented Xe134 2nubb decay (adjusted Q value)
            * Qbb= 0.843 MeV
     - implemented Xe124 ECEC, ECb+, b+b+ (adjusted Q value and K X-ray) 
            * Q = 3.068 MeV
            * K_\alpha X-ray : 27.8 keV
	- Replaced old continuation character (+) by the one for tab form (any digit except 0)
		* sed "/^[     +]*/ s/     +/     9/g" decay0.1.for > decay0.1.new.for

11/01/2013 : 
	- Imported original DECAY0 code and started converting into DECAY0.1 so that Eclipse Photran can parse it successfully.
	- Replaced the old comments (starting with 'c') with the following command:
		* sed "/^[c]*/ s/c/\!c/g" test.txt 
